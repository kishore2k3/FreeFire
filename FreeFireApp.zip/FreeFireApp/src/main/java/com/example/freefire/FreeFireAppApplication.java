package com.example.freefire;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreeFireAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreeFireAppApplication.class, args);
	}

}
